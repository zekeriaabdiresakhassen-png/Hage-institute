HAGE INSTITUTE FOR QUR'AN AL-KARIM — WEBSITE FILES

Files:
- index.html  = main website page
- logo.jpg    = HAGE Institute logo

For GitHub Pages:
1. Create a public GitHub repository named hage-institute.
2. Upload BOTH index.html and logo.jpg to the top/root of the repository.
3. Open Settings -> Pages.
4. Choose Deploy from a branch -> main -> / (root) -> Save.
5. GitHub Pages will publish the site. The URL will normally be:
   https://YOUR-GITHUB-USERNAME.github.io/hage-institute/

Do not rename index.html. GitHub Pages uses it as the site's entry file.
